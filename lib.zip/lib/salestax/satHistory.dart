import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:fincal/salestax/salestaxModel.dart';
import 'package:fincal/salestax/salestaxHelper.dart';
import 'package:fincal/salestax/sales_tax_screen.dart'; // Import SalesTaxScreen

class HistoryPage extends StatefulWidget {
  @override
  _HistoryPageState createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  late List<SalesTax> _salesTaxList;
  late List<bool> _isSelected;
  bool _isSelecting = false;

  @override
  void initState() {
    super.initState();
    _loadSalesTax();
  }

  Future<void> _loadSalesTax() async {
    final salesTaxList = await DatabaseHelper.getAllSalesTax();
    setState(() {
      _salesTaxList = salesTaxList;
      _isSelected = List<bool>.filled(salesTaxList.length, false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: _isSelecting
            ? Text('Selected ${_selectedItemCount()}')
            : Text(
                'Sales Tax History',
                style: TextStyle(color: Colors.white),
              ),
        backgroundColor: Colors.green,
        iconTheme: IconThemeData(color: Colors.white),
        actions: _buildAppBarActions(),
      ),
      body: _salesTaxList.isEmpty
          ? Center(child: Text('No sales tax data available'))
          : ListView.separated(
              itemCount: _salesTaxList.length,
              separatorBuilder: (context, index) => Divider(),
              itemBuilder: (context, index) {
                final salesTax = _salesTaxList[index];
                final formattedDate =
                    _formattedDate(salesTax.datetime!); // Asserting datetime
                return GestureDetector(
                  onLongPress: () {
                    setState(() {
                      _isSelecting = true;
                      _isSelected[index] = !_isSelected[index];
                    });
                  },
                  onTap: () {
                    if (_isSelecting) {
                      setState(() {
                        _isSelected[index] = !_isSelected[index];
                      });
                    } else {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              SalesTaxScreen(salesTax: salesTax),
                        ),
                      );
                    }
                  },
                  child: Row(
                    children: [
                      Checkbox(
                        value: _isSelected[index],
                        onChanged: (value) {
                          setState(() {
                            _isSelected[index] = value!;
                          });
                        },
                      ),
                      Expanded(
                        flex: 1,
                        child: Card(
                          color: Colors.green,
                          elevation: 4,
                          child: Container(
                            height: 100,
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  formattedDate[0], // Month
                                  style: TextStyle(
                                    fontSize: 18.0,
                                    color: Colors.white,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                Text(
                                  formattedDate[1], // Day
                                  style: TextStyle(
                                    fontSize: 18.0,
                                    color: Colors.white,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                Text(
                                  formattedDate[2], // Year
                                  style: TextStyle(
                                    fontSize: 18.0,
                                    color: Colors.white,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 8.0),
                      Expanded(
                        flex: 3,
                        child: ListTile(
                          title: Text(
                            'Net Price: ${salesTax.netPrice}\nSales Price : ${salesTax.salesTaxRate}',
                            style: TextStyle(
                              color: isDarkMode ? Colors.white : Colors.black,
                            ),
                          ),
                          subtitle: Text(
                            'Sales Tax Amount: ${salesTax.salesTaxAmount}\nTotal Price : ${salesTax.totalPrice}',
                            style: TextStyle(
                              color: isDarkMode ? Colors.white : Colors.black,
                            ),
                          ),
                          trailing: _isSelecting
                              ? Icon(Icons.arrow_forward_ios)
                              : null,
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 8.0),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  List<String> _formattedDate(String datetime) {
    final parsedDate = DateTime.parse(datetime);
    final month = DateFormat('MMM').format(parsedDate);
    final day = DateFormat('dd').format(parsedDate);
    final year = DateFormat('yyyy').format(parsedDate);
    return [month, day, year];
  }

  List<Widget> _buildAppBarActions() {
    if (_isSelecting) {
      return [
        IconButton(
          icon: Icon(Icons.delete),
          onPressed: () {
            _deleteSelected();
          },
        ),
        IconButton(
          icon: Icon(Icons.cancel),
          onPressed: () {
            _cancelSelection();
          },
        ),
      ];
    } else {
      return [
        IconButton(
          icon: Icon(Icons.select_all),
          onPressed: () {
            _selectAll();
          },
        ),
      ];
    }
  }

  int _selectedItemCount() {
    return _isSelected.where((selected) => selected).length;
  }

  void _selectAll() {
    setState(() {
      _isSelecting = true;
      _isSelected = List<bool>.filled(_salesTaxList.length, true);
    });
  }

  void _deleteSelected() {
    final selectedIndices = _isSelected
        .asMap()
        .entries
        .where((entry) => entry.value)
        .map((entry) => entry.key)
        .toList();
    for (final index in selectedIndices.reversed) {
      final salesTax = _salesTaxList[index];
      DatabaseHelper.deleteSalesTax(salesTax.id!);
      _salesTaxList.removeAt(index);
      _isSelected.removeAt(index);
    }
    setState(() {
      _isSelecting = false;
    });
  }

  void _cancelSelection() {
    setState(() {
      _isSelecting = false;
      _isSelected = List<bool>.filled(_salesTaxList.length, false);
    });
  }
}

class WallpaperOption {
  final String name;
  final String imageUrl;

  WallpaperOption({required this.name, required this.imageUrl});
}

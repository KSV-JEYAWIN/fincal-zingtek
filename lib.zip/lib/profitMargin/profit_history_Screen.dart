import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:fincal/profitMargin/profitmaginModel.dart';
import 'package:fincal/profitMargin/profitmarginHelper.dart';
import 'profit_margin_screen.dart'; // Import your ProfitMarginScreen widget

class HistoryPage extends StatefulWidget {
  const HistoryPage({Key? key}) : super(key: key);

  @override
  _HistoryPageState createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  late List<ProfitMargin> _profitMargins;
  late List<bool> _selectedItems;
  bool _isInSelectionMode = false;

  @override
  void initState() {
    super.initState();
    _selectedItems = List<bool>.generate(100, (index) => false);
    DBHelper.instance.getAllProfitMargins().then((value) {
      setState(() {
        _profitMargins = value;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        iconTheme: const IconThemeData(
          color: Colors.white,
        ),
        title: _isInSelectionMode
            ? null
            : Text(
                'History',
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
        actions: [
          if (_isInSelectionMode)
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  IconButton(
                    onPressed: _cancelSelection,
                    icon: Icon(Icons.cancel),
                  ),
                  IconButton(
                    onPressed: _deleteSelectedItems,
                    icon: Icon(Icons.delete),
                  ),
                ],
              ),
            ),
          if (!_isInSelectionMode)
            IconButton(
              onPressed: _selectAll,
              icon: Icon(Icons.select_all),
            ),
          if (!_isInSelectionMode)
            PopupMenuButton(
              itemBuilder: (context) => [
                PopupMenuItem(
                  value: 'deleteAll',
                  child: Text('Delete All'),
                ),
              ],
              onSelected: (value) {
                if (value == 'deleteAll') {
                  _deleteAllItems();
                }
              },
            ),
        ],
      ),
      body: _profitMargins != null
          ? ListView.builder(
              itemCount: _profitMargins.length,
              itemBuilder: (context, index) {
                if (index.isOdd) {
                  return Divider(); // Add a divider between items
                }
                final itemIndex = index ~/ 2;
                ProfitMargin profitMargin = _profitMargins[itemIndex];
                Color textColor =
                    Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black;
                return GestureDetector(
                  onLongPress: () {
                    _startSelection();
                    _selectItem(itemIndex);
                  },
                  onTap: () {
                    if (_isInSelectionMode) {
                      _selectItem(itemIndex);
                    } else {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ProfitMarginScreen(
                            costPrice: profitMargin.costPrice,
                            sellingPrice: profitMargin.sellingPrice,
                            unitsSold: profitMargin.unitsSold,
                          ),
                        ),
                      );
                    }
                  },
                  child: Row(
                    children: [
                      Expanded(
                        flex: 1,
                        child: SizedBox(
                          height: 130, // Adjust the height of the card
                          child: Card(
                            color: _selectedItems[itemIndex]
                                ? Colors.grey
                                : Colors.green,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    '${_formattedDate(profitMargin.dateTime)[0]}',
                                    // Month
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18.0,
                                    ),
                                  ),
                                  Text(
                                    '${_formattedDate(profitMargin.dateTime)[1]}',
                                    // Day
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18.0,
                                    ),
                                  ),
                                  Text(
                                    '${_formattedDate(profitMargin.dateTime)[2]}',
                                    // Year
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18.0,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 8.0),
                      Expanded(
                        flex: 3,
                        child: ListTile(
                          title: Text(
                            'Cost Price: ${profitMargin.costPrice}\nSelling Price : ${profitMargin.sellingPrice}\nNumber of Unit Sold : ${profitMargin.unitsSold}',
                            style: TextStyle(color: textColor),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Profit Amount : ${profitMargin.profitAmount}\nProfit Percentage : ${profitMargin.profitPercentage}',
                                style: TextStyle(color: textColor),
                              ),
                            ],
                          ),
                          trailing: _selectedItems[itemIndex]
                              ? IconButton(
                                  icon: Icon(Icons.check_circle),
                                  onPressed: () {
                                    _selectItem(itemIndex);
                                  },
                                )
                              : null,
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 8.0),
                        ),
                      ),
                    ],
                  ),
                );
              },
            )
          : Center(
              child: CircularProgressIndicator(),
            ),
    );
  }

  List<String> _formattedDate(DateTime datetime) {
    final parsedDate = datetime ?? DateTime.now();
    final month = '${DateFormat('MMM').format(parsedDate)}';
    final day = '${DateFormat('dd').format(parsedDate)}';
    final year = '${DateFormat('yyyy').format(parsedDate)}';
    return [month, day, year];
  }

  void _startSelection() {
    setState(() {
      _isInSelectionMode = true;
    });
  }

  void _cancelSelection() {
    setState(() {
      _isInSelectionMode = false;
      _selectedItems = List<bool>.filled(_selectedItems.length, false);
    });
  }

  void _selectItem(int index) {
    setState(() {
      _selectedItems[index] = !_selectedItems[index];
    });
  }

  void _selectAll() {
    setState(() {
      for (int i = 0; i < _selectedItems.length; i++) {
        _selectedItems[i] = true;
      }
    });
  }

  void _deleteSelectedItems() {
    List<int> selectedIndexes = [];
    for (int i = 0; i < _selectedItems.length; i++) {
      if (_selectedItems[i]) {
        selectedIndexes.add(i);
      }
    }
    selectedIndexes.sort((a, b) =>
        b.compareTo(a)); // Delete from the last index to avoid index shifting
    for (int index in selectedIndexes) {
      ProfitMargin item = _profitMargins[index];
      DBHelper.instance.deleteProfitMargin(item.id!);
      _profitMargins.removeAt(index);
    }
    _cancelSelection();
  }

  void _deleteAllItems() {
    for (var item in _profitMargins) {
      DBHelper.instance.deleteProfitMargin(item.id!);
    }
    setState(() {
      _profitMargins.clear();
    });
  }
}

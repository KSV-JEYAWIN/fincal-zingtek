import 'package:flutter/material.dart';
import 'package:fincal/tip_calculator/tipmodel.dart';
import 'package:fincal/tip_calculator/tip_screen.dart';
import 'package:fincal/tip_calculator/tiphelper.dart';
import 'package:intl/intl.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({Key? key}) : super(key: key);

  @override
  _HistoryPageState createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  late List<Tip> _tips;
  late List<bool> _isSelected;
  bool _isSelecting = false;

  @override
  void initState() {
    super.initState();
    _loadTips();
  }

  Future<void> _loadTips() async {
    final tips = await DatabaseHelper().getAllTips();
    setState(() {
      _tips = tips ?? [];
      _isSelected = List<bool>.filled(tips?.length ?? 0, false);
    });
  }

  void _selectAll() {
    setState(() {
      for (int i = 0; i < _isSelected.length; i++) {
        _isSelected[i] = true;
      }
    });
  }

  void _deleteSelected() async {
    final List<Tip> selectedTips = [];
    for (int i = 0; i < _isSelected.length; i++) {
      if (_isSelected[i]) {
        selectedTips.add(_tips[i]);
      }
    }
    for (final tip in selectedTips) {
      if (tip.id != null) {
        await DatabaseHelper().deleteTip(tip.id!);
      }
    }
    _loadTips();
    setState(() {
      _isSelecting = false;
    });
  }

  void _cancelSelection() {
    setState(() {
      _isSelecting = false;
      _isSelected = List<bool>.filled(_tips.length, false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: _isSelecting
            ? Row(
                children: [
                  Expanded(
                    child: Text('Selected ${_selectedItemCount()}'),
                  ),
                ],
              )
            : Text(
                'Tip History',
                style: TextStyle(color: Colors.white),
              ),
        actions:
            _isSelecting ? _buildSelectingActions() : _buildAppBarActions(),
        iconTheme: const IconThemeData(color: Colors.white),
        actionsIconTheme: IconThemeData(
            color: Colors
                .white), // Ensure icon color matches the app bar text color
      ),
      body: _tips.isEmpty
          ? Center(child: Text('No history available'))
          : ListView.separated(
              itemCount: _tips.length,
              separatorBuilder: (BuildContext context, int index) => Divider(),
              itemBuilder: (context, index) {
                final tip = _tips[index];
                final dateTime = DateTime.parse(tip.datetime);
                return GestureDetector(
                  onLongPress: () {
                    setState(() {
                      _isSelecting = true;
                      _isSelected[index] = true;
                    });
                  },
                  onTap: () {
                    if (_isSelecting) {
                      setState(() {
                        _isSelected[index] = !_isSelected[index];
                      });
                    } else {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => TipScreen(initialTip: tip),
                        ),
                      );
                    }
                  },
                  child: ListTile(
                    leading: _isSelecting
                        ? Checkbox(
                            value: _isSelected[index],
                            onChanged: (value) {
                              setState(() {
                                _isSelected[index] = value!;
                              });
                            },
                          )
                        : null,
                    title: Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: Card(
                            color: Colors.green,
                            child: Padding(
                              padding: const EdgeInsets.all(14.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    '${_formattedDate(dateTime)[0]}',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 24.0,
                                    ),
                                  ),
                                  Text(
                                    '${_formattedDate(dateTime)[1]}',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 24.0,
                                    ),
                                  ),
                                  Text(
                                    '${_formattedDate(dateTime)[2]}',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 24.0,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 8.0),
                        Expanded(
                          flex: 3,
                          child: ListTile(
                            title: Text(
                              'Bill Amount : ${tip.billAmount}\nTip Percentage : ${tip.tipPercentage}\nNumber of Person : ${tip.numberOfPersons}',
                              style: TextStyle(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Tip Amount: ${tip.tipAmount}\nTotal Amount : ${tip.totalAmount}\nAmount Per person : ${tip.amountPerPerson}',
                                  style: TextStyle(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: _isSelecting
          ? null
          : FloatingActionButton(
              onPressed: () {
                setState(() {
                  _isSelecting = true;
                  _selectAll();
                });
              },
              child: Icon(Icons.select_all),
            ),
    );
  }

  List<String> _formattedDate(DateTime datetime) {
    final month = '${DateFormat('MMM').format(datetime)}';
    final day = '${DateFormat('dd').format(datetime)}';
    final year = '${DateFormat('yyyy').format(datetime)}';
    return [month, day, year];
  }

  List<Widget> _buildAppBarActions() {
    return [
      IconButton(
        icon: Icon(Icons.select_all),
        onPressed: () {
          setState(() {
            _isSelecting = true;
            _selectAll();
          });
        },
      ),
    ];
  }

  List<Widget> _buildSelectingActions() {
    return [
      IconButton(
        icon: Icon(Icons.delete),
        onPressed: _deleteSelected,
      ),
      IconButton(
        icon: Icon(Icons.cancel),
        onPressed: _cancelSelection,
      ),
    ];
  }

  int _selectedItemCount() {
    return _isSelected.where((selected) => selected).length;
  }
}
